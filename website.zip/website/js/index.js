async function send(event) {
     event.preventDefault();
      const token = await grecaptcha.getResponse();
      if (!token) {
        alert("Please complete the CAPTCHA");
        return;
      }
      // verify captcha on server
      const verifyRes = await fetch("https://recaptcha-wjf7.onrender.com/verify-captcha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          token,
          param : {
            name: document.getElementById("name").value,
            email: document.getElementById("email").value,
            message: document.getElementById("message").value,
            confirm: document.getElementById("consent").value,
            number: document.getElementById("telephone").value
          }
         })
      });
      const verifyData = await verifyRes.json();
      if (!verifyData.success) {
        alert("Captcha failed. Try again.");
        console.log(verifyData.message);
        grecaptcha.reset();
        return;
      }
      else{
        alert("Form submitted successfully!");
        console.log(verifyData.message);
        grecaptcha.reset();
        document.querySelector("form").reset();
        return;
      }
}